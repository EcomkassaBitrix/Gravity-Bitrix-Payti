<?php

$arModuleVersion = [
    'VERSION' => '1.0.1',
    'VERSION_DATE' => '2025-12-30'
];
