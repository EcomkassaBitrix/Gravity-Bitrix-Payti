<?php

$arModuleVersion = [
    'VERSION' => '1.0.2',
    'VERSION_DATE' => '2026-02-19'
];
